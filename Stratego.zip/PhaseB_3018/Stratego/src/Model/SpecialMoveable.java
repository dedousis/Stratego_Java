/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author andre_000
 */
enum power {

    Fly, Speed, Arrow, Trap_, Move_scout, Dragon_Slayer
}

public abstract class SpecialMoveable extends MoveablePiece {

    power power2;

    /**
     * Pre Set the rank and the power of specialmoved pieces
     *
     * @param rank of the piece
     * @param p the special power
     * 
     * Pro Set the rank and the power of specialmoved pieces
     */
    public SpecialMoveable(int rank, power p,color c) {
        super(rank,c);
        this.power2 = p;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author andre_000
 */
public class Beast_Rider extends SpecialMoveable {

    /**
     *
     * @param c
     */
    public Beast_Rider(color c) {
        super(7, power.Speed,c);
    }

   
}

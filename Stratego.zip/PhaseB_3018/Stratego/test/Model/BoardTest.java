/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author andre_000
 */
public class BoardTest {
    
    public BoardTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of set_tablo method, of class Board.
     */
    @Test
    public void testSet_tablo() {
        System.out.println("set_tablo");
        int row = 0;
        int column = 0;
        Piece p = null;
        Board instance = new Board();
        instance.set_tablo(row, column, p);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of get_Piece method, of class Board.
     */
    @Test
    public void testGet_Piece() {
        System.out.println("get_Piece");
        int row = 0;
        int col = 0;
        Board instance = new Board();
        Piece expResult = null;
        Piece result = instance.get_Piece(row, col);
//        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of init_P method, of class Board.
     */
    @Test
    public void testInit_P() {
        System.out.println("init_P");
        Board instance = new Board();
        instance.init_P();
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getP1_play method, of class Board.
     */
    @Test
    public void testGetP1_play() {
        System.out.println("getP1_play");
        Board instance = new Board();
        boolean expResult = true;
        boolean result = instance.getP1_play();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getP2_play method, of class Board.
     */
    @Test
    public void testGetP2_play() {
        System.out.println("getP2_play");
        Board instance = new Board();
        boolean expResult = false;
        boolean result = instance.getP2_play();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author andre_000
 */
public abstract class Piece {

    static enum color {

        Volcandria, Everwinter
    };
    private color COLOR;
    private int x;
    private int y;
    private int rank;

    /**
     * Pre Connstructor whick gives to the piece color and rank
     *
     * @param rank
     * @param c
     *
     * Post Connstructor whick gives to the piece color and rank
     */
    public Piece(int rank, color c) {
        this.COLOR = c;
        this.rank = rank;
    }

    public Piece() {

    }

    /**
     * Pre Return the team of each piece
     *
     * @return
     *
     * Post Return the team of each piece
     */
    public color getColor() {
        return this.COLOR;
    }

    /**
     * Pre Set the row of the piece
     *
     * @param row of the pice on the board
     *
     * Post Set the row of the piece
     */
    public void setrow(int row) {
        this.x = row;
    }

    /**
     * Pre Return the row of the piece
     *
     * @param row of the piece
     * @return the row of piece
     *
     * Post return the row of the piece
     */
    public int getrow() {
        return this.x;
    }

    /**
     * Pre Set in which column the piece is
     *
     * @param column of the piece
     *
     * post: Set in which column the piece is
     */
    public void setcol(int column) {
        this.y = column;
    }

    /**
     * Pre Return tthe col of the Piece
     *
     * @return the column of the piece on the board
     *
     * Post Return tthe col of the Piece
     */
    public int getcol() {
        return this.y;
    }

    /**
     * pre Return the rank of the piece
     *
     * @return
     *
     * Post retutn the rank of the piece
     */
    public int getrank() {
        return this.rank;
    }
}

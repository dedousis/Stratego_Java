/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 * 
 * @author andre_000
 */
public class Scout extends SpecialMoveable {

    public Scout(color c)
    {
        super(2,power.Move_scout,c);
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author andre_000
 */
public class Lava_Beast extends MoveablePiece { 
    /**
     * 
     * @param rank 
     */
    public Lava_Beast()
    {
        super(5,color.Volcandria);
    }

}

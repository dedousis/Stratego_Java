/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author andre_000
 */
public class Dragon extends SpecialMoveable {
    
    /**
     * 
     * @param c
     */
    public Dragon(color c)
    {
        super(10,power.Fly,c);
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author andre_000
 */
public abstract class MoveablePiece extends Piece 
{
    private int rank;

    /**
     *Pre constructor set the rank of the piece 
     * @param rank of the piece
     * @param c
     * 
     * Post constructor set the rank of the piece 
     */
    public MoveablePiece(int rank,color c)
    {
        super(rank ,c);
    }

}

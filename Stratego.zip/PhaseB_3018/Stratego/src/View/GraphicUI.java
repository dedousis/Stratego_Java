/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

/**
 *
 * @author andre_000
 */
import Model.*;
import static Model.Board.game;
import javax.swing.*;
import java.awt.*;
import static java.awt.Color.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GraphicUI extends JFrame {

    private static final int row = 8;
    private static final int columns = 10;

    // private Controller game;
    private Board table;
    private JFrame battleground;
    private JPanel panel;
    private JLabel Everwinter, Volcandria;
    private JButton[][] buttons = new JButton[8][10];
    private CardListener clickedButton;

    private JButton selectedButton;
    private boolean iconSelected;

    /**
     * Pre : create the window and initialize some buttons
     *
     * @throws java.io.IOException
     *
     * Post create the window and controls all the buttons and the settings of
     * the game
     */
    public GraphicUI() throws IOException {
        super("Stratego");
        setIconImage(new ImageIcon(getClass().getResource("images.png")).getImage());
        //game = new Controller();
        table = new Board();
        setBackground(Color.black);
        // setExtendedState(JFrame.MAXIMIZED_BOTH); 
        setSize(1320, 900);
        //setUndecorated(true);
        setResizable(false);
        Volcandria = new JLabel("" + game.getSideP2() + "  " + game.get_piecesLeftP2());
        Everwinter = new JLabel("" + game.getSideP1() + "  " + game.get_piecesLeftP1());

        panel = new JPanel();
        panel.setLayout(new GridLayout(row, columns, 3, 3));
        panel.setMinimumSize(new Dimension(500, 100));
        panel.setPreferredSize(new Dimension(500, 100));
        add(Volcandria, BorderLayout.SOUTH);
        add(Everwinter, BorderLayout.NORTH);
        // newgame.setPreferredSize(new Dimension(2,1));
        initialize_button_pieces();
        moirasma();
        add(panel);
        iconSelected = false;
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
    }

    /**
     * Pre initialize the buttons to be ready to start the game
     *
     *
     * Post initialize the buttons
     */
    public void initialize_button_pieces() {
        for (int j = 0; j < 8; j++) {
            for (int i = 0; i < 10; i++) {
                if (j <= 2) {
                    ImageIcon b = new ImageIcon(getClass().getResource("blueHidden.png"));
                    Image image = b.getImage();
                    image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                    b.setImage(image);
                    buttons[j][i] = new JButton(b);
                    buttons[j][i].setName("piece");
                    buttons[j][i].setBackground(Color.blue);
                    buttons[j][i].setBorder(BorderFactory.createLineBorder(Color.black));
                } else if (j >= 5) {

                    ImageIcon b = new ImageIcon(getClass().getResource("redHidden.png"));
                    Image image = b.getImage();
                    image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                    b.setImage(image);
                    buttons[j][i] = new JButton(b);
                    buttons[j][i].setName("piece");
                    buttons[j][i].setBackground(Color.red);
                    buttons[j][i].setBorder(BorderFactory.createLineBorder(Color.black));
                } else {
                    if ((j == 3 && i == 2) || (j == 3 && i == 3) || (j == 4 && i == 2) || (j == 4 && i == 3) || (j == 3 && i == 6) || (j == 3 && i == 7) || (j == 4 && i == 6) || (j == 4 && i == 7)) {
                        Icon b = new ImageIcon(getClass().getResource("X.png"));
                        buttons[j][i] = new JButton(b);
                        buttons[j][i].setName("X");
                        buttons[j][i].setBorderPainted(false);
                        buttons[j][i].setFocusPainted(false);
                    } else {
                        buttons[j][i] = new JButton();
                        buttons[j][i].setIcon(null);
                        buttons[j][i].setBackground(Color.WHITE);
                        buttons[j][i].setBorder(BorderFactory.createLineBorder(Color.black));
                    }
                }
                panel.add(buttons[j][i], JLayeredPane.DEFAULT_LAYER);
            }
        }
    }

    /**
     * Pre initialize the pieces and controls the moves and the attacks
     *
     *
     *
     * Post all the pieces are initialized and finished the game
     *
     */
    public void moirasma() {
        clickedButton = new CardListener();

        int o = 0, L = 0;
        int k = 0, n = 0;
        for (int j = 0; j < 8; j++) {

            for (int i = 0; i < 10; i++) {

                buttons[j][i].setBorder(BorderFactory.createLineBorder(Color.black));

                if (j <= 2) {
                    int rank2 = table.get_Piece(j, i).getrank();//game.getPieces_P2().get(k).getrank();
                    if (rank2 == 10) {
                        ImageIcon b = new ImageIcon(getClass().getResource("dragonB.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank2);
                        buttons[j][i].setText("" + game.getSideP2());
                        buttons[j][i].setRolloverIcon(b);
                        k++;
                    } else if (rank2 == 9) {
                        ImageIcon b = new ImageIcon(getClass().getResource("mageB.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank2);
                        buttons[j][i].setText("" + game.getSideP2());
                        buttons[j][i].setRolloverIcon(b);
                        k++;
                    } else if (rank2 == 8) {
                        ImageIcon b = new ImageIcon(getClass().getResource("knightB.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank2);
                        buttons[j][i].setText("" + game.getSideP2());
                        buttons[j][i].setRolloverIcon(b);
                        k++;
                    } else if (rank2 == 7) {
                        ImageIcon b = new ImageIcon(getClass().getResource("beastRiderB.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank2);
                        buttons[j][i].setText("" + game.getSideP2());
                        buttons[j][i].setRolloverIcon(b);
                        k++;
                    } else if (rank2 == 6) {
                        ImageIcon b = new ImageIcon(getClass().getResource("sorceressB.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank2);
                        buttons[j][i].setText("" + game.getSideP2());
                        buttons[j][i].setRolloverIcon(b);
                        k++;
                    } else if (rank2 == 5) {
                        ImageIcon b = new ImageIcon(getClass().getResource("yeti.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank2);
                        buttons[j][i].setText("" + game.getSideP2());
                        buttons[j][i].setRolloverIcon(b);
                        k++;
                    } else if (rank2 == 4) {
                        ImageIcon b = new ImageIcon(getClass().getResource("elfB.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank2);
                        buttons[j][i].setText("" + game.getSideP2());
                        buttons[j][i].setRolloverIcon(b);
                        k++;
                    } else if (rank2 == 3) {
                        ImageIcon b = new ImageIcon(getClass().getResource("dwarfB.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank2);
                        buttons[j][i].setText("" + game.getSideP2());
                        buttons[j][i].setRolloverIcon(b);
                        k++;
                    } else if (rank2 == 2) {
                        ImageIcon b = new ImageIcon(getClass().getResource("scoutB_1.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank2);
                        buttons[j][i].setText("" + game.getSideP2());
                        buttons[j][i].setRolloverIcon(b);
                        k++;
                    } else if (rank2 == 1) {
                        ImageIcon b = new ImageIcon(getClass().getResource("slayerB.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank2);
                        buttons[j][i].setText("" + game.getSideP2());
                        buttons[j][i].setRolloverIcon(b);
                        k++;
                    } else if (rank2 == 0) {
                        ImageIcon b = new ImageIcon(getClass().getResource("trapB.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        ImageIcon x = new ImageIcon(getClass().getResource("flagB.png"));
                        Image imge = x.getImage();
                        imge = imge.getScaledInstance(imge.getWidth(null) - 5, imge.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        x.setImage(imge);
                        if (L == 0) {

                            buttons[j][i].setName("FLAG");
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(x);

                            k++;
                            L = 1;
                        } else {

                            buttons[j][i].setName("BOMB");
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(b);

                            k++;
                        }
                        // }
                    }
                } else if (j >= 5) {

                    // if (n < si1) {
                    int rank = table.get_Piece(j, i).getrank();//game.getPieces_P1().get(n).getrank();

                    if (rank == 10) {
                        ImageIcon b = new ImageIcon(getClass().getResource("dragonR.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank);
                        buttons[j][i].setText("" + game.getSideP1());
                        buttons[j][i].setRolloverIcon(b);
                        n++;
                    } else if (rank == 9) {
                        ImageIcon b = new ImageIcon(getClass().getResource("mageR.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank);
                        buttons[j][i].setText("" + game.getSideP1());
                        buttons[j][i].setRolloverIcon(b);
                        n++;
                    } else if (rank == 8) {
                        ImageIcon b = new ImageIcon(getClass().getResource("knightR.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank);
                        buttons[j][i].setText("" + game.getSideP1());
                        buttons[j][i].setRolloverIcon(b);
                        n++;
                    } else if (rank == 7) {
                        ImageIcon b = new ImageIcon(getClass().getResource("beastRiderR.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank);
                        buttons[j][i].setText("" + game.getSideP1());
                        buttons[j][i].setRolloverIcon(b);
                        n++;
                    } else if (rank == 6) {
                        ImageIcon b = new ImageIcon(getClass().getResource("sorceressR.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank);
                        buttons[j][i].setText("" + game.getSideP1());
                        buttons[j][i].setRolloverIcon(b);
                        n++;
                    } else if (rank == 5) {
                        ImageIcon b = new ImageIcon(getClass().getResource("lavaBeast.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank);
                        buttons[j][i].setText("" + game.getSideP1());
                        buttons[j][i].setRolloverIcon(b);
                        n++;
                    } else if (rank == 4) {
                        ImageIcon b = new ImageIcon(getClass().getResource("elfR.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank);
                        buttons[j][i].setText("" + game.getSideP1());
                        buttons[j][i].setRolloverIcon(b);
                        n++;
                    } else if (rank == 3) {
                        ImageIcon b = new ImageIcon(getClass().getResource("dwarfR.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank);
                        buttons[j][i].setText("" + game.getSideP1());
                        buttons[j][i].setRolloverIcon(b);
                        n++;
                    } else if (rank == 2) {
                        ImageIcon b = new ImageIcon(getClass().getResource("scoutB.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank);
                        buttons[j][i].setText("" + game.getSideP1());
                        buttons[j][i].setRolloverIcon(b);
                        n++;
                    } else if (rank == 1) {
                        ImageIcon b = new ImageIcon(getClass().getResource("slayerR.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        buttons[j][i].setName("" + rank);
                        buttons[j][i].setRolloverIcon(b);
                        n++;
                    } else if (rank == 0) {
                        ImageIcon b = new ImageIcon(getClass().getResource("trapR.png"));
                        Image image = b.getImage();
                        image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        b.setImage(image);
                        ImageIcon x = new ImageIcon(getClass().getResource("flagR.png"));
                        Image imge = x.getImage();
                        imge = imge.getScaledInstance(imge.getWidth(null) - 5, imge.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        x.setImage(imge);
                        if (o == 0) {

                            buttons[j][i].setName("FLAG");
                            buttons[j][i].setText("" + game.getSideP1());
                            buttons[j][i].setRolloverIcon(x);

                            n++;
                            o = 1;
                        } else {

                            buttons[j][i].setName("BOMB");
                            buttons[j][i].setText("" + game.getSideP1());
                            buttons[j][i].setRolloverIcon(b);

                            n++;
                        }
                        // }
                    }
                }

                panel.add(buttons[j][i], JLayeredPane.DEFAULT_LAYER);
                buttons[j][i].addMouseListener(clickedButton);

            }

        }
    }

    /**
     * Pre take a random piece from the dead and come to life
     *
     * @param p
     * @return
     *
     * Post take a random piece from the dead and come to life
     */
    public JButton makeRes_p1(Piece p) {
        if (p != null) {
            for (int j = 0; j < 8; j++) {
                for (int i = 0; i < 10; i++) {
                    if (buttons[j][i].getBackground() == white) {
                        buttons[j][i].setBackground(red);
                        ImageIcon x = new ImageIcon(getClass().getResource("redHidden.png"));
                        Image imge = x.getImage();
                        imge = imge.getScaledInstance(imge.getWidth(null) - 5, imge.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        x.setImage(imge);
                        buttons[j][i].setIcon(x);
                        int rank = p.getrank();
                        buttons[j][i].setText("" + game.getSideP1() + "  " + rank);
                        buttons[j][i].setName("" + rank);
                        if (rank == 10) {
                            ImageIcon b = new ImageIcon(getClass().getResource("dragonR.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank);
                            buttons[j][i].setText("" + game.getSideP1());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank == 9) {
                            ImageIcon b = new ImageIcon(getClass().getResource("mageR.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank);
                            buttons[j][i].setText("" + game.getSideP1());
                            buttons[j][i].setRolloverIcon(b);
                        } else if (rank == 8) {
                            ImageIcon b = new ImageIcon(getClass().getResource("knightR.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank);
                            buttons[j][i].setText("" + game.getSideP1());
                            buttons[j][i].setRolloverIcon(b);
                        } else if (rank == 7) {
                            ImageIcon b = new ImageIcon(getClass().getResource("beastRiderR.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank);
                            buttons[j][i].setText("" + game.getSideP1());
                            buttons[j][i].setRolloverIcon(b);
                        } else if (rank == 6) {
                            ImageIcon b = new ImageIcon(getClass().getResource("sorceressR.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank);
                            buttons[j][i].setText("" + game.getSideP1());
                            buttons[j][i].setRolloverIcon(b);
                        } else if (rank == 5) {
                            ImageIcon b = new ImageIcon(getClass().getResource("lavaBeast.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank);
                            buttons[j][i].setText("" + game.getSideP1());
                            buttons[j][i].setRolloverIcon(b);
                        } else if (rank == 4) {
                            ImageIcon b = new ImageIcon(getClass().getResource("elfR.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank);
                            buttons[j][i].setText("" + game.getSideP1());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank == 3) {
                            ImageIcon b = new ImageIcon(getClass().getResource("dwarfR.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank);
                            buttons[j][i].setText("" + game.getSideP1());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank == 2) {
                            ImageIcon b = new ImageIcon(getClass().getResource("scoutB.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank);
                            buttons[j][i].setText("" + game.getSideP1());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank == 1) {
                            ImageIcon b = new ImageIcon(getClass().getResource("slayerR.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank);
                            buttons[j][i].setRolloverIcon(b);
                        }
                        table.set_tablo(j, i, p);
                        table.get_Piece(j, i).setrow(j);
                        table.get_Piece(j, i).setcol(i);
                        return buttons[j][i];
                    }
                }
            }
        }
        return null;
    }

    /**
     * Pre take a random piece from the dead and come to life
     *
     * @param p
     * @return
     *
     * Post take a random piece from the dead and come to life
     */
    public JButton makeRes_p2(Piece p) {
        if (p != null) {
            for (int j = 0; j < 8; j++) {
                for (int i = 0; i < 10; i++) {
                    if (buttons[j][i].getBackground() == white) {
                        buttons[j][i].setBackground(red);
                        ImageIcon x = new ImageIcon(getClass().getResource("blueHidden.png"));
                        Image imge = x.getImage();
                        imge = imge.getScaledInstance(imge.getWidth(null) - 5, imge.getHeight(null) / 2, Image.SCALE_SMOOTH);
                        x.setImage(imge);
                        buttons[j][i].setIcon(x);
                        int rank2 = p.getrank();
                        if (rank2 == 10) {
                            ImageIcon b = new ImageIcon(getClass().getResource("dragonB.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank2);
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank2 == 9) {
                            ImageIcon b = new ImageIcon(getClass().getResource("mageB.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank2);
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank2 == 8) {
                            ImageIcon b = new ImageIcon(getClass().getResource("knightB.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank2);
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank2 == 7) {
                            ImageIcon b = new ImageIcon(getClass().getResource("beastRiderB.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank2);
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank2 == 6) {
                            ImageIcon b = new ImageIcon(getClass().getResource("sorceressB.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank2);
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank2 == 5) {
                            ImageIcon b = new ImageIcon(getClass().getResource("yeti.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank2);
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank2 == 4) {
                            ImageIcon b = new ImageIcon(getClass().getResource("elfB.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank2);
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank2 == 3) {
                            ImageIcon b = new ImageIcon(getClass().getResource("dwarfB.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank2);
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank2 == 2) {
                            ImageIcon b = new ImageIcon(getClass().getResource("scoutB_1.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank2);
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(b);

                        } else if (rank2 == 1) {
                            ImageIcon b = new ImageIcon(getClass().getResource("slayerB.png"));
                            Image image = b.getImage();
                            image = image.getScaledInstance(image.getWidth(null) - 5, image.getHeight(null) / 2, Image.SCALE_SMOOTH);
                            b.setImage(image);
                            buttons[j][i].setName("" + rank2);
                            buttons[j][i].setText("" + game.getSideP2());
                            buttons[j][i].setRolloverIcon(b);

                        }

                        table.set_tablo(j, i, p);
                        table.get_Piece(j, i).setrow(j);
                        table.get_Piece(j, i).setcol(i);
                        return buttons[j][i];
                    }
                }
            }
        }
        return null;
    }

    private class CardListener implements MouseListener {

        /**
         * Pre When e (mouse clicked) check which move has to be done
         *
         * @param e
         *
         * Post All the moves or attacks has been done and the game is over
         */
        @Override
        public void mouseClicked(MouseEvent e) {
            JButton but = ((JButton) e.getSource());

            if (iconSelected && !but.equals(selectedButton) && but.getBackground() != selectedButton.getBackground() && but.getName() != "X") { // move(swap) buttons
                if (selectedButton.getBackground() == red) {//P1
                    Rectangle r = but.getBounds();
                    Point p = but.getLocation();
                    int row = p.y / r.height;
                    int col = p.x / r.width;
                    int op = Integer.parseInt(selectedButton.getName());
                    Rectangle r1 = selectedButton.getBounds();
                    Point p1 = selectedButton.getLocation();
                    int row1 = p1.y / r1.height;
                    int col1 = p1.x / r1.width;
                    if (row == table.get_Piece(row1, col1).getrow() + 1 && col == table.get_Piece(row1, col1).getcol()
                            || row == table.get_Piece(row1, col1).getrow() - 1 && col == table.get_Piece(row1, col1).getcol()
                            || col == table.get_Piece(row1, col1).getcol() - 1 && row == table.get_Piece(row1, col1).getrow()
                            || col == table.get_Piece(row1, col1).getcol() + 1 && row == table.get_Piece(row1, col1).getrow()
                            || op == 2 && table.get_Piece(row1 + 1, col1) == null
                            || op == 2 && table.get_Piece(row1 - 1, col1) == null
                            || op == 2 && table.get_Piece(row1, col1 + 1) == null
                            || op == 2 && table.get_Piece(row1 + 1, col1 - 1) == null) {

                        table.set_tablo(row, col, table.get_Piece(row1, col1));
                        table.get_Piece(row1, col1).setrow(row);
                        table.get_Piece(row1, col1).setcol(col);
                        if (but.getName() == null ? selectedButton.getName() == null : but.getName().equals(selectedButton.getName() /*Objects.equals(Integer.parseInt(but.getName()), Integer.parseInt(selectedButton.getName()))*/)) {
                            but.setIcon(null);//if equal
                            but.setRolloverIcon(null);
                            int l = Integer.parseInt(but.getName());
                            but.setBackground(Color.white);
                            but.setText(null);
                            but.setName(null);
                            selectedButton.setText(null);
                            selectedButton.setIcon(null);
                            selectedButton.setBackground(Color.white);
                            selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                            selectedButton.setName(null);
                            selectedButton.setText(null);
                            selectedButton = but;
                            iconSelected = false;
                            if (row == 0 && game.Ress_P1() != null) {
                                makeRes_p1(game.Ress_P1());
                                // iconSelected = false;
                            }
                            game.add_dead_p1(l);
                            game.add_dead_p2(l);
                            int pl1 = game.get_piecesLeftP1();
                            int pl2 = game.get_piecesLeftP2();
                            Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                            Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                            add(Volcandria, BorderLayout.NORTH);
                            add(Everwinter, BorderLayout.SOUTH);

                        } else if (but.getName() == null || "FLAG".equals(but.getName()) || but.getName() == "BOMB") {// just move
                            if ("BOMB".equals(but.getName())) {
                                int s = Integer.parseInt(selectedButton.getName());
                                if (s == 3) {
                                    but.setIcon(selectedButton.getIcon());
                                    but.setRolloverIcon(selectedButton.getRolloverIcon());
                                    but.setBackground(selectedButton.getBackground());
                                    but.setName(selectedButton.getName());
                                    but.setText(selectedButton.getText());
                                    selectedButton.setText(null);
                                    selectedButton.setIcon(null);
                                    selectedButton.setBackground(Color.white);
                                    selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                    selectedButton.setName(null);
                                    selectedButton = but;
                                    iconSelected = false;
                                    if (row == 0 && game.Ress_P1() != null) {
                                        makeRes_p1(game.Ress_P1());
                                        // iconSelected = false;
                                    }
                                    game.add_dead_p2(0);
                                    int pl2 = game.get_piecesLeftP2();
                                    int pl1 = game.get_piecesLeftP2();
                                    Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                                    Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                                    add(Volcandria, BorderLayout.NORTH);
                                    add(Everwinter, BorderLayout.SOUTH);

                                } else if (s != 3) {
                                    selectedButton.setText(null);
                                    selectedButton.setIcon(null);
                                    selectedButton.setBackground(Color.white);
                                    selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                    selectedButton.setName(null);
                                    selectedButton = but;
                                    iconSelected = false;
                                    if (row == 0 && game.Ress_P1() != null) {
                                        makeRes_p1(game.Ress_P1());
                                        // iconSelected = false;
                                    }
                                    game.add_dead_p1(s);
                                    int pl1 = game.get_piecesLeftP1();
                                    int pl2 = game.get_piecesLeftP2();
                                    int d1;
                                    Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                                    Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                                    add(Volcandria, BorderLayout.NORTH);
                                    add(Everwinter, BorderLayout.SOUTH);
                                }
                            } else if ("FLAG".equals(but.getName())) {
                                but.setIcon(selectedButton.getIcon());
                                but.setRolloverIcon(selectedButton.getRolloverIcon());
                                but.setBackground(selectedButton.getBackground());
                                but.setName(selectedButton.getName());
                                but.setText(selectedButton.getText());
                                selectedButton.setText(null);
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton = but;
                                iconSelected = false;

                                JFrame frame = new JFrame("WIN");
                                frame.setVisible(true);
                                frame.setSize(500, 200);
                                frame.setLayout(new FlowLayout());
                                frame.setResizable(false);
                                JPanel panel2 = new JPanel();
                                JLabel winner = new JLabel("" + game.getSideP1() + "  WINNER IS: " + game.getName_P1());
                                frame.add(winner);
                                //frame.addMouseListener(this);
                                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                                //add(frame);
                            } else {
                                but.setIcon(selectedButton.getIcon());
                                but.setRolloverIcon(selectedButton.getRolloverIcon());
                                but.setBackground(selectedButton.getBackground());
                                but.setName(selectedButton.getName());
                                but.setText(selectedButton.getText());
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton.setText(null);

                                selectedButton = but;
                                iconSelected = false;
                                if (row == 0 && game.Ress_P1() != null) {
                                    makeRes_p1(game.Ress_P1());
                                    // iconSelected = false;
                                }
                            }
                        } else if (!but.getName().equals(selectedButton.getName()) && but.getName() != "BOMB" && but.getName() != "FLAG") {
                            int b = Integer.parseInt(but.getName());
                            int s = Integer.parseInt(selectedButton.getName());
                            if (s > b) {
                                but.setIcon(selectedButton.getIcon());
                                but.setRolloverIcon(selectedButton.getRolloverIcon());
                                but.setBackground(selectedButton.getBackground());
                                but.setName(selectedButton.getName());
                                but.setText(selectedButton.getText());
                                selectedButton.setText(null);
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton = but;
                                iconSelected = false;
                                if (row == 0 && game.Ress_P1() != null) {
                                    makeRes_p1(game.Ress_P1());
                                    // iconSelected = false;
                                }
                                game.add_dead_p2(b);
                                int pl1 = game.get_piecesLeftP1();
                                int pl2 = game.get_piecesLeftP2();
                                Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                                Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                                add(Volcandria, BorderLayout.NORTH);
                                add(Everwinter, BorderLayout.SOUTH);
                            } else if (s < b && s != 1 && b != 10) {
                                selectedButton.setText(null);
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton = but;
                                iconSelected = false;
                                if (row == 0 && game.Ress_P1() != null) {
                                    makeRes_p1(game.Ress_P1());
                                    // iconSelected = false;
                                }
                                game.add_dead_p1(s);
                                int pl1 = game.get_piecesLeftP1();
                                int pl2 = game.get_piecesLeftP2();
                                Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                                Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                                add(Volcandria, BorderLayout.NORTH);
                                add(Everwinter, BorderLayout.SOUTH);
                            } else if ((s == 1 && b == 10) || (s == 10 && b == 1)) {
                                but.setIcon(selectedButton.getIcon());
                                but.setRolloverIcon(selectedButton.getRolloverIcon());
                                but.setBackground(selectedButton.getBackground());
                                but.setName(selectedButton.getName());
                                but.setText(selectedButton.getText());
                                selectedButton.setText(null);
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton = but;
                                iconSelected = false;
                                if (row == 0 && game.Ress_P1() != null) {
                                    makeRes_p1(game.Ress_P1());
                                    // iconSelected = false;
                                }
                                game.add_dead_p2(b);
                                int pl1 = game.get_piecesLeftP1();
                                int pl2 = game.get_piecesLeftP2();
                                Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                                Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                                add(Volcandria, BorderLayout.NORTH);
                                add(Everwinter, BorderLayout.SOUTH);
                            } else {
                                selectedButton.setText(null);
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton = but;
                                iconSelected = false;
                                if (row == 0 && game.Ress_P1() != null) {
                                    makeRes_p1(game.Ress_P1());
                                    // iconSelected = false;
                                }

                            }
                        }
                    }
                } else if (selectedButton.getBackground() == blue) {//P2
                    Rectangle r = but.getBounds();
                    Point p = but.getLocation();
                    int row = p.y / r.height;
                    int col = p.x / r.width;
                    Rectangle r1 = selectedButton.getBounds();
                    int op = Integer.parseInt(selectedButton.getName());
                    Point p1 = selectedButton.getLocation();
                    int row1 = p1.y / r1.height;
                    int col1 = p1.x / r1.width;
                    if (row == table.get_Piece(row1, col1).getrow() + 1 && col == table.get_Piece(row1, col1).getcol()
                            || row == table.get_Piece(row1, col1).getrow() - 1 && col == table.get_Piece(row1, col1).getcol()
                            || col == table.get_Piece(row1, col1).getcol() - 1 && row == table.get_Piece(row1, col1).getrow()
                            || col == table.get_Piece(row1, col1).getcol() + 1 && row == table.get_Piece(row1, col1).getrow()
                            || op == 2 && table.get_Piece(row1 + 1, col1) == null
                            || op == 2 && table.get_Piece(row1 - 1, col1) == null
                            || op == 2 && table.get_Piece(row1, col1 + 1) == null
                            || op == 2 && table.get_Piece(row1 + 1, col1 - 1) == null) {

                        table.set_tablo(row, col, table.get_Piece(row1, col1));
                        table.get_Piece(row1, col1).setrow(row);
                        table.get_Piece(row1, col1).setcol(col);

                        if (but.getName() == null ? selectedButton.getName() == null : but.getName().equals(selectedButton.getName() /*Objects.equals(Integer.parseInt(but.getName()), Integer.parseInt(selectedButton.getName()))*/)) {
                            but.setIcon(null);//if equal
                            but.setRolloverIcon(null);
                            int l = Integer.parseInt(but.getName());
                            but.setName(null);
                            but.setBackground(Color.white);
                            but.setText(null);
                            selectedButton.setText(null);
                            selectedButton.setIcon(null);
                            selectedButton.setBackground(Color.white);
                            selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                            selectedButton.setName(null);
                            selectedButton.setText(null);
                            selectedButton = but;
                            iconSelected = false;
                            if (row == 7 && game.Ress_P2() != null) {
                                makeRes_p2(game.Ress_P2());
                                // iconSelected = false;
                            }
                            game.add_dead_p1(l);
                            game.add_dead_p2(l);
                            int pl1 = game.get_piecesLeftP1();
                            int pl2 = game.get_piecesLeftP2();
                            Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                            Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                            add(Volcandria, BorderLayout.NORTH);
                            add(Everwinter, BorderLayout.SOUTH);

                        } else if (but.getName() == null || "FLAG".equals(but.getName()) || but.getName() == "BOMB") {// just move
                            if ("BOMB".equals(but.getName())) {
                                int s = Integer.parseInt(selectedButton.getName());
                                if (s == 3) {
                                    but.setIcon(selectedButton.getIcon());
                                    but.setRolloverIcon(selectedButton.getRolloverIcon());
                                    but.setBackground(selectedButton.getBackground());
                                    but.setName(selectedButton.getName());
                                    but.setText(selectedButton.getText());
                                    selectedButton.setText(null);
                                    selectedButton.setIcon(null);
                                    selectedButton.setBackground(Color.white);
                                    selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                    selectedButton.setName(null);
                                    selectedButton = but;
                                    iconSelected = false;
                                    if (row == 7 && game.Ress_P2() != null) {
                                        makeRes_p2(game.Ress_P2());
                                        // iconSelected = false;
                                    }
                                    game.add_dead_p1(0);
                                    int pl1 = game.get_piecesLeftP1();
                                    int pl2 = game.get_piecesLeftP2();
                                    Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                                    Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                                    add(Volcandria, BorderLayout.NORTH);
                                    add(Everwinter, BorderLayout.SOUTH);
                                } else if (s != 3) {
                                    selectedButton.setText(null);
                                    selectedButton.setIcon(null);
                                    selectedButton.setBackground(Color.white);
                                    selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                    selectedButton.setName(null);
                                    selectedButton = but;
                                    iconSelected = false;
                                    if (row == 7 && game.Ress_P2() != null) {
                                        makeRes_p2(game.Ress_P2());
                                        // iconSelected = false;
                                    }
                                    game.add_dead_p2(s);
                                    int pl1 = game.get_piecesLeftP1();
                                    int pl2 = game.get_piecesLeftP2();
                                    Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                                    Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                                    Volcandria.setText("" + game.getSideP1() + "  " + pl1);
                                    add(Volcandria, BorderLayout.NORTH);
                                    add(Everwinter, BorderLayout.SOUTH);
                                }
                            } else if ("FLAG".equals(but.getName())) {
                                but.setIcon(selectedButton.getIcon());
                                but.setRolloverIcon(selectedButton.getRolloverIcon());
                                but.setBackground(selectedButton.getBackground());
                                but.setName(selectedButton.getName());
                                but.setText(selectedButton.getText());
                                selectedButton.setText(null);
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton = but;
                                iconSelected = false;

                                JFrame frame = new JFrame("WIN");
                                frame.setVisible(true);
                                frame.setSize(500, 200);
                                frame.setLayout(new FlowLayout());
                                frame.setResizable(false);
                                JPanel panel2 = new JPanel();
                                JLabel winner = new JLabel("" + game.getSideP2() + "  WINNER IS: " + game.getName_P2());
                                frame.add(winner);
                                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            } else {
                                but.setIcon(selectedButton.getIcon());
                                but.setRolloverIcon(selectedButton.getRolloverIcon());
                                but.setBackground(selectedButton.getBackground());
                                but.setName(selectedButton.getName());
                                but.setText(selectedButton.getText());
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton.setText(null);
                                if (row == 7 && game.Ress_P2() != null) {
                                    makeRes_p2(game.Ress_P2());
                                    // iconSelected = false;
                                }
                                selectedButton = but;
                                iconSelected = false;
                            }
                        } else if (!but.getName().equals(selectedButton.getName()) && but.getName() != "BOMB" && but.getName() != "FLAG") {
                            int b = Integer.parseInt(but.getName());
                            int s = Integer.parseInt(selectedButton.getName());
                            if (s > b) {
                                but.setIcon(selectedButton.getIcon());
                                but.setRolloverIcon(selectedButton.getRolloverIcon());
                                but.setBackground(selectedButton.getBackground());
                                but.setName(selectedButton.getName());
                                but.setText(selectedButton.getText());
                                selectedButton.setText(null);
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton = but;
                                iconSelected = false;
                                if (row == 7 && game.Ress_P2() != null) {
                                    makeRes_p2(game.Ress_P2());
                                    // iconSelected = false;
                                }
                                game.add_dead_p1(b);
                                int pl1 = game.get_piecesLeftP1();
                                int pl2 = game.get_piecesLeftP2();
                                Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                                Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                                add(Volcandria, BorderLayout.NORTH);
                                add(Everwinter, BorderLayout.SOUTH);
                            } else if (s < b && s != 1 && b != 10) {
                                selectedButton.setText(null);
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton = but;
                                iconSelected = false;
                                if (row == 7 && game.Ress_P2() != null) {
                                    makeRes_p2(game.Ress_P2());
                                    // iconSelected = false;
                                }
                                game.add_dead_p2(s);
                                int pl1 = game.get_piecesLeftP1();
                                int pl2 = game.get_piecesLeftP2();
                                Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                                Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                                add(Volcandria, BorderLayout.NORTH);
                                add(Everwinter, BorderLayout.SOUTH);
                            } else if ((s == 1 && b == 10) || (s == 10 && b == 1)) {
                                but.setIcon(selectedButton.getIcon());
                                but.setRolloverIcon(selectedButton.getRolloverIcon());
                                but.setBackground(selectedButton.getBackground());
                                but.setName(selectedButton.getName());
                                but.setText(selectedButton.getText());
                                selectedButton.setText(null);
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton = but;
                                iconSelected = false;
                                if (row == 7 && game.Ress_P2() != null) {
                                    makeRes_p2(game.Ress_P2());
                                    // iconSelected = false;
                                }
                                game.add_dead_p1(b);
                                int pl1 = game.get_piecesLeftP1();
                                int pl2 = game.get_piecesLeftP2();
                                Volcandria.setText("" + game.getSideP1() + "  " + pl1 + " Dead: " + game.getDead_P1() + "  Ress:" + game.num_res_P1());
                                Everwinter.setText("" + game.getSideP2() + "  " + pl2 + " Dead: " + game.getDead_P2() + "  Ress:" + game.num_res_P2());
                                add(Volcandria, BorderLayout.NORTH);
                                add(Everwinter, BorderLayout.SOUTH);
                            } else {
                                selectedButton.setText(null);
                                selectedButton.setIcon(null);
                                selectedButton.setBackground(Color.white);
                                selectedButton.setBorder(BorderFactory.createLineBorder(Color.black));
                                selectedButton.setName(null);
                                selectedButton = but;
                                iconSelected = false;
                                if (row == 7 && game.Ress_P2() != null) {
                                    makeRes_p2(game.Ress_P2());
                                    // iconSelected = false;
                                }
                            }
                        }
                    }
                }
            } else if (but.isSelected() == false && but.getIcon() != null && but.isFocusPainted() == true) { //if not selected icon then select 

                if ("FLAG".equals(but.getName()) || but.getName() == "BOMB") {
                } else {
                    if (table.getP1_play() == true && but.getBackground() == red) {
                        iconSelected = true;
                        selectedButton = but;
                        // makeRed_vis();
                        game.P1_play = false;
                        game.P2_play = true;
                    } else if (table.getP2_play() == true && but.getBackground() == blue) {
                        iconSelected = true;
                        selectedButton = but;
                        game.P2_play = false;
                        game.P1_play = true;
                    }
                }
            }
        }

        @Override
        public void mousePressed(MouseEvent e
        ) {
        }

        @Override
        public void mouseReleased(MouseEvent e
        ) {

        }

        @Override
        public void mouseEntered(MouseEvent e
        ) {

        }

        @Override
        public void mouseExited(MouseEvent e
        ) {
        }

    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author andre_000
 */
public class PlayerTest {
    
    public PlayerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getSide method, of class Player.
     */
    @Test
    public void testGetSide() {
        System.out.println("getSide");
        Player instance = null;
        Player.team expResult = null;
        Player.team result = instance.getSide();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of setRess method, of class Player.
     */
    @Test
    public void testSetRess() {
        System.out.println("setRess");
        int r = 0;
        Player instance = null;
        instance.setRess(r);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getRess method, of class Player.
     */
    @Test
    public void testGetRess() {
        System.out.println("getRess");
        Player instance = null;
        int expResult = 0;
        int result = instance.getRess();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of hasRess method, of class Player.
     */
    @Test
    public void testHasRess() {
        System.out.println("hasRess");
        Player instance = null;
        boolean expResult = false;
        boolean result = instance.hasRess();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of Ress method, of class Player.
     */
    @Test
    public void testRess() {
        System.out.println("Ress");
        Player instance = null;
        instance.Ress();
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of setPieces_left method, of class Player.
     */
    @Test
    public void testSetPieces_left() {
        System.out.println("setPieces_left");
        Player instance = null;
        instance.setPieces_left();
        // TODO review the generated test code and remove the default call to fail.
 
    }

    /**
     * Test of getPiece_left method, of class Player.
     */
    @Test
    public void testGetPiece_left() {
        System.out.println("getPiece_left");
        Player instance = null;
        int expResult = 30;
        int result = instance.getPiece_left();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getName method, of class Player.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Player instance = null;
        String expResult = "";
        String result = instance.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of hasPlayed method, of class Player.
     */
    @Test
    public void testHasPlayed() {
        System.out.println("hasPlayed");
        Player instance = null;
        boolean expResult = false;
        boolean result = instance.hasPlayed();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of play method, of class Player.
     */
    @Test
    public void testPlay() {
        System.out.println("play");
        Player instance = null;
        instance.play();
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of add_to_play method, of class Player.
     */
    @Test
    public void testAdd_to_play() {
        System.out.println("add_to_play");
        Piece p = null;
        Player instance = null;
        instance.add_to_play(p);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of add_to_dead method, of class Player.
     */
    @Test
    public void testAdd_to_dead() {
        System.out.println("add_to_dead");
        Piece p = null;
        Player instance = null;
        instance.add_to_dead(p);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of remove_from_play method, of class Player.
     */
    @Test
    public void testRemove_from_play() {
        System.out.println("remove_from_play");
        Piece p = null;
        Player instance = null;
        instance.remove_from_play(p);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of remove_from_dead method, of class Player.
     */
    @Test
    public void testRemove_from_dead() {
        System.out.println("remove_from_dead");
        Player instance = null;
        Piece expResult = null;
        Piece result = instance.remove_from_dead();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of Get_all method, of class Player.
     */
    @Test
    public void testGet_all() {
        System.out.println("Get_all");
        Player instance = null;
        ArrayList<Piece> expResult = null;
        ArrayList<Piece> result = instance.Get_all();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of Get_dead method, of class Player.
     */
    @Test
    public void testGet_dead() {
        System.out.println("Get_dead");
        Player instance = null;
        int expResult = 0;
        int result = instance.Get_dead();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of get_Piece method, of class Player.
     */
    @Test
    public void testGet_Piece() {
        System.out.println("get_Piece");
        int rank = 0;
        Player instance = null;
        Piece expResult = null;
        Piece result = instance.get_Piece(rank);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of init_piecesP1 method, of class Player.
     */
    @Test
    public void testInit_piecesP1() {
        System.out.println("init_piecesP1");
        Player instance = null;
        instance.init_piecesP1();
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of init_piecesP2 method, of class Player.
     */
    @Test
    public void testInit_piecesP2() {
        System.out.println("init_piecesP2");
        Player instance = null;
        instance.init_piecesP2();
        // TODO review the generated test code and remove the default call to fail.

    }
    
}

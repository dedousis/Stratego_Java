/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author andre_000
 */
public abstract class ImmovablePiece extends Piece {

    private String name;

    /**
     * Pre Constructor for the bombs and the flags
     *
     * @param name
     * @param c side
     *
     * Post Constructor for the bombs and the flags
     */
    public ImmovablePiece(String name, color c) {
        super(0, c);
        this.name = name;

    }

    /**
     * pre constructor for forbiden areas
     *
     * @param name post constructor for forbiden areas
     */
    public ImmovablePiece(String name) {
        this.name = name;
    }

    /**
     * pre return the name of the pieces
     *
     * @return
     *
     * return the name of the pieces
     */
    public String getName() {
        return this.name;
    }
}

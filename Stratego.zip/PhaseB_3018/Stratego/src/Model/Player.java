/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Model.Piece.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author andre_000
 */
public class Player {

    public enum team {

        Everwinter, Volcandria
    };
    private String name;
    private team side;
    private int pieces_left, ress_done, pieces_dead;
    private ArrayList<Piece> Pieces_to_play;
    private ArrayList<Piece> Dead;
    private boolean Played, finished, has_ress;

    /**
     * <b>constructor</b>:Creates and initializes a player with given
     *
     * @param name of the player<br/>
     * @param c the team <br/>
     *
     * <b>postcondition</b>Create 2 array lists the one for the pieces that are
     * alive ad the othe for dead Also create the pieces and initialize a
     * counter for how many pieces lef initialize th number of ress of each
     * player
     */
    public Player(String name, team c) {
        this.name = name;
        Pieces_to_play = new ArrayList<Piece>();
        Dead = new ArrayList<Piece>();
        this.pieces_left = 30;
        this.pieces_dead = 0;
        this.ress_done = 0;
        this.side = c;
        this.Played = false;
        if (c == team.Volcandria) {
            init_piecesP1();
        } else {
            init_piecesP2();
        }
        Collections.shuffle(Pieces_to_play);
    }

    /**
     * <b>accessor</b>:Return the team of the player
     * <p>
     * <b>PostCondition:</b>return the tea of the player<br />
     *
     * @return
     */
    public team getSide() {
        if(side!=null){
        return this.side;
        }
        return null;
    }

    /**
     * pre: set the number od ress has been done
     *
     * @param r post:se the variable ress_done egua to the num
     */
    public void setRess(int r) {
        this.ress_done = r;
    }

    /**
     * Pre: return the number of ress Post return the number of ress
     *
     * @return
     */
    public int getRess() {
        return this.ress_done;
    }

    /**
     * pre:take the ress varible and if its diferent than 0 return true
     *
     * @return true if the player has ressed post:take the ress varible and if
     * its diferent than 0 return true
     */
    public boolean hasRess() {
        if (this.has_ress == true) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Pre: set the has_ress variabe true if the player has ressed Post set the
     * has_ress true and increase the counter
     */
    public void Ress() {
        this.has_ress = true;
        ress_done++;
    }

    /**
     * Pre if a piece is dead the dicrease the num Post if a piece is dead the
     * dicrease the num
     */
    public void setPieces_left() {
        this.pieces_left--;
    }

    /**
     * Pre Return the num of the pieces has bbeen left Post return the number of
     * pieces left
     *
     * @return
     */
    public int getPiece_left() {
        return this.pieces_left;
    }

    /**
     * Pre return the name of the player Post return the nme of the player
     *
     * @return the name of the player
     */
    public String getName() {
        return this.name;
    }

    /**
     * Pre:set the boolean var Played true if the player has played Post: set
     * the boolean var Played true if the player has played
     */
    public boolean hasPlayed() {
        if (this.Played == true) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Pre set true the variable to choose between the players Post set true the
     * variable to choose between the players
     */
    public void play() {
        this.Played = true;

    }

    /**
     * Pre :Add p to the alive arraylist
     *
     * @param p Post P added to the alive arraylist after ressed
     */
    public void add_to_play(Piece p) {
        if (hasRess() == true && ress_done <= 2) {
            Pieces_to_play.add(p);
        }

    }

    /**
     * Add dead piece p to the dead array
     *
     * @param p
     */
    public void add_to_dead(Piece p) {
        Dead.add(p);
        this.pieces_dead++;
    }

    /**
     * Pre:if piece p lost the battle will go the dead arraylist and dicrease
     * pieces left
     *
     * @param p Post :if piece p lost the battle will go the dead arraylist and
     * dicrease pieces left
     */
    public void remove_from_play(Piece p) {
        Pieces_to_play.remove(p);
        add_to_dead(p);
        setPieces_left();
    }

    /**
     * Pre Search the dead arraylist and find the piece p and resurect it and
     * add it again to alive
     *
     * @param p Post Search the dead arraylist and find the piece p and resurect
     * it and add it again to alive
     */
    public Piece remove_from_dead() {
        Random rand = new Random();
        int size = Dead.size();
        int piece = rand.nextInt((size) - 0 + 1);
        for (int i = 0; i < size; i++) {
            if (i == piece) {
                if (this.ress_done <= 3) {
                    this.ress_done++;
                    this.pieces_dead--;
                    Pieces_to_play.add(Dead.get(i));
                    return Dead.get(i);
                }
            }
        }
        return null;
    }

    /**
     * Pre Return all the pieces of the arraylist
     *
     * @return Post return all the pieces of the arraylist
     */
    public ArrayList<Piece> Get_all() {
        return this.Pieces_to_play;
    }

    /**
     * Pre return the num of dead pieces
     *
     * @return
     *
     * Pro return th num of dead pieces
     */
    public int Get_dead() {
        return this.pieces_dead;
    }

    /**
     * Pre Return a piece from the arraylist with rank
     *
     * @param rank
     * @return Post Return a piece from the arraylist with rank
     */
    public Piece get_Piece(int rank) {
        for (int i = 0; i < Pieces_to_play.size(); i++) {
            if (Pieces_to_play.get(i).getrank() == rank) {
                return Pieces_to_play.get(i);
            }
        }
        return null;
    }

    /**
     * Pre:Initialize the pieces and add them to the arraylist to play depended
     * on the side Post:nitialize the pieces and add them to the arraylist to
     * play
     */
    public void init_piecesP1() {
        Pieces_to_play.add(new Dragon(color.Volcandria));
        Pieces_to_play.add(new Mage(color.Volcandria));
        Pieces_to_play.add(new Knight(color.Volcandria));
        Pieces_to_play.add(new Knight(color.Volcandria));
        Pieces_to_play.add(new Beast_Rider(color.Volcandria));
        Pieces_to_play.add(new Beast_Rider(color.Volcandria));
        Pieces_to_play.add(new Beast_Rider(color.Volcandria));
        Pieces_to_play.add(new Sorceress(color.Volcandria));
        Pieces_to_play.add(new Sorceress(color.Volcandria));
        Pieces_to_play.add(new Lava_Beast());
        Pieces_to_play.add(new Lava_Beast());
        Pieces_to_play.add(new Elf(color.Volcandria));
        Pieces_to_play.add(new Elf(color.Volcandria));
        Pieces_to_play.add(new Dwarf(color.Volcandria));
        Pieces_to_play.add(new Dwarf(color.Volcandria));
        Pieces_to_play.add(new Dwarf(color.Volcandria));
        Pieces_to_play.add(new Dwarf(color.Volcandria));
        Pieces_to_play.add(new Dwarf(color.Volcandria));
        Pieces_to_play.add(new Scout(color.Volcandria));
        Pieces_to_play.add(new Scout(color.Volcandria));
        Pieces_to_play.add(new Scout(color.Volcandria));
        Pieces_to_play.add(new Scout(color.Volcandria));
        Pieces_to_play.add(new Slayer(color.Volcandria));
        Pieces_to_play.add(new Bomb(color.Volcandria));
        Pieces_to_play.add(new Bomb(color.Volcandria));
        Pieces_to_play.add(new Bomb(color.Volcandria));
        Pieces_to_play.add(new Bomb(color.Volcandria));
        Pieces_to_play.add(new Bomb(color.Volcandria));
        Pieces_to_play.add(new Bomb(color.Volcandria));
        Pieces_to_play.add(new Flag(color.Volcandria));
    }

    /**
     * Pre:Initialize the pieces and add them to the arraylist to play depended
     * on the side Post:nitialize the pieces and add them to the arraylist to
     * play
     */
    public void init_piecesP2() {
        Pieces_to_play.add(new Dragon(color.Everwinter));
        Pieces_to_play.add(new Mage(color.Everwinter));
        Pieces_to_play.add(new Knight(color.Everwinter));
        Pieces_to_play.add(new Knight(color.Everwinter));
        Pieces_to_play.add(new Beast_Rider(color.Everwinter));
        Pieces_to_play.add(new Beast_Rider(color.Everwinter));
        Pieces_to_play.add(new Beast_Rider(color.Everwinter));
        Pieces_to_play.add(new Sorceress(color.Everwinter));
        Pieces_to_play.add(new Sorceress(color.Everwinter));
        Pieces_to_play.add(new Yeti());
        Pieces_to_play.add(new Yeti());
        Pieces_to_play.add(new Elf(color.Everwinter));
        Pieces_to_play.add(new Elf(color.Everwinter));
        Pieces_to_play.add(new Dwarf(color.Everwinter));
        Pieces_to_play.add(new Dwarf(color.Everwinter));
        Pieces_to_play.add(new Dwarf(color.Everwinter));
        Pieces_to_play.add(new Dwarf(color.Everwinter));
        Pieces_to_play.add(new Dwarf(color.Everwinter));
        Pieces_to_play.add(new Scout(color.Everwinter));
        Pieces_to_play.add(new Scout(color.Everwinter));
        Pieces_to_play.add(new Scout(color.Everwinter));
        Pieces_to_play.add(new Scout(color.Everwinter));
        Pieces_to_play.add(new Slayer(color.Everwinter));
        Pieces_to_play.add(new Bomb(color.Everwinter));
        Pieces_to_play.add(new Bomb(color.Everwinter));
        Pieces_to_play.add(new Bomb(color.Everwinter));
        Pieces_to_play.add(new Bomb(color.Everwinter));
        Pieces_to_play.add(new Bomb(color.Everwinter));
        Pieces_to_play.add(new Bomb(color.Everwinter));
        Pieces_to_play.add(new Flag(color.Everwinter));
    }
}

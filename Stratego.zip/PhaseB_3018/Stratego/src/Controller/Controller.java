/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.*;
import Model.Player.team;
import java.util.ArrayList;

/**
 *
 * @author andre_000
 */
public class Controller {

    private Player P1, P2, last_player;
    private ArrayList<Player> players = new ArrayList<Player>();
    public boolean empty_table, P1_play, P2_play;
    Board tablo;

    /**
     * Pre COnstructor which initilizes the players
     *
     * post COnstructor which initilizes the players
     */
    public Controller() {
        P1 = new Player("Makis", team.Volcandria);
        P2 = new Player("Soula", team.Everwinter);
        //tablo = new Board();
        players.add(P1);
        players.add(P2);
        this.empty_table = true;
        P1_play = true;
        P2_play = false;
    }

    /**
     * pre Ress piece p
     *
     * @return
     *
     * Post ress piece p
     */
    public Piece Ress_P1() {
        return this.P1.remove_from_dead();
    }

    /**
     * pre Ress piece p
     *
     * @return
     *
     * Post ress piece p
     */
    public Piece Ress_P2() {
        return this.P2.remove_from_dead();
    }

    /**
     * Pre return the num of ress
     *
     * @return
     *
     * Post return the num of ress
     */
    public int num_res_P1() {
        return this.P1.getRess();
    }

    /**
     * Pre return the num of ress
     *
     * @return
     *
     * Post return the num of ress
     */
    public int num_res_P2() {
        return this.P2.getRess();
    }

    /**
     * Pre return if player has played
     *
     * @return
     *
     * Post return if player has played
     */
    public boolean P1_play() {
        return this.P1_play;
    }

    /**
     * Pre return if player has played
     *
     * @return
     *
     * Post return if player has played
     */
    public boolean P2_play() {
        return this.P2_play;
    }

    /**
     * Pre Return all the pieces of the player
     *
     * @return
     *
     * Post Return all the pieces of the player
     */
    public ArrayList<Piece> getPieces_P1() {
        if (P1.Get_all() == null) {
            return null;
        } else {
            return P1.Get_all();
        }
    }

    /**
     * Pre Return all the pieces of the player
     *
     * @return
     *
     * Post Return all the pieces of the player
     */
    public ArrayList<Piece> getPieces_P2() {
        if (P2.Get_all() == null) {
            return null;
        } else {
            return P2.Get_all();
        }
    }

    /**
     * PreReturn the rank of piece p
     *
     * @param rank
     * @return
     *
     * Post Return the rank of piece p
     */
    public Piece getP1(int rank) {
        return P1.get_Piece(rank);
    }

    /**
     * PreReturn the rank of piece p
     *
     * @param rank
     * @return
     *
     * Post Return the rank of piece p
     */
    public Piece getP2(int rank) {
        return P2.get_Piece(rank);
    }

    /**
     * Pre when a piece is dead add it to the dead arraylist
     *
     * @param rank
     *
     * POst when a piece is dead add it to the dead arraylist
     */
    public void add_dead_p1(int rank) {
        // P1.add_to_dead(getP1(rank));
        P1.remove_from_play(getP1(rank));
    }

    /**
     * Pre when a piece is dead add it to the dead arraylist
     *
     * @param rank
     *
     * POst when a piece is dead add it to the dead arraylist
     */
    public void add_dead_p2(int rank) {
        //P2.add_to_dead(getP2(rank));
        P2.remove_from_play(getP2(rank));
    }

    /**
     * pre return the team
     *
     * @return
     *
     * Post retutn the team
     */
    public team getSideP1() {
        return P1.getSide();
    }

    /**
     * pre return the team
     *
     * @return
     *
     * Post retutn the team
     */
    public team getSideP2() {
        return P2.getSide();
    }

    /**
     * Pre set the coodridantes of the piece p
     *
     * @param row
     * @param columns
     * @param p
     *
     * Post set the coodridantes of the piece p
     */
    public void setCordinates(int row, int columns, Piece p) {
        if(p!=null){
        tablo.set_tablo(row, columns, p);
        }
    }

    /**
     * pre get the coodridantes and return piece
     *
     * @param row
     * @param columns
     * @return post get the coodridantes and return piece
     */
    public Piece getCordinates(int row, int columns) {
        if(tablo.get_Piece(row, columns)!=null)
        {
        return tablo.get_Piece(row, columns);
    }else{
        return null;
        }
    }

    /**
     * Pre get pieces alive
     *
     * @return
     *
     * post return the pieces alive
     */
    public int get_piecesLeftP1() {
        return P1.getPiece_left();
    }

    /**
     * Pre get pieces alive
     *
     * @return
     *
     * post return the pieces alive
     */
    public int get_piecesLeftP2() {
        return P2.getPiece_left();
    }

    /**
     * pre Return the name of the player
     *
     * @return
     *
     * post Return the name of the player
     */
    public String getName_P1() {
        return P1.getName();
    }

    /**
     * pre Return the name of the player
     *
     * @return
     *
     * post Return the name of the player
     */
    public String getName_P2() {
        return P2.getName();
    }

    /**
     * Pre Return the num of dead piece
     *
     * @return
     *
     * POst Return the num of dead piece
     */
    public int getDead_P1() {
        return P1.Get_dead();
    }

    /**
     * Pre Return the num of dead piece
     *
     * @return
     *
     * POst Return the num of dead piece
     */
    public int getDead_P2() {
        return P2.Get_dead();
    }

    /**
     * pre set the las tplayer played
     *
     * @param p player
     *
     * post set the las tplayer played
     */
    public void SetLast(Player p) {
        this.last_player = p;
    }

    /**
     * pre get the last played
     *
     * @return the last player
     *
     * Postget the last played
     */
    public Player getLast() {
        return this.last_player;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Controller.Controller;

/**
 *
 * @author andre_000
 */
public class Board {

    public Piece[][] A = new Piece[8][10];
    public static Controller game;

    /**
     *
     * Pre:Constructor Initiaalize the board to play and set the forbidden areas
     *
     *
     * Post:Constructor Initiaalize the board to play and set the forbidden
     * areas and initializes the coordinates of the pieces
     */
    public Board() {
        A[3][2] = new Rocks();
        A[3][3] = new Rocks();
        A[3][6] = new Rocks();
        A[3][7] = new Rocks();
        A[4][2] = new Rocks();
        A[4][3] = new Rocks();
        A[4][6] = new Rocks();
        A[4][7] = new Rocks();
        A[3][2].setrow(3);
        A[3][2].setcol(2);
        A[3][3].setrow(3);
        A[3][3].setcol(3);
        A[3][6].setrow(3);
        A[3][6].setcol(6);
        A[3][7].setrow(3);
        A[3][7].setcol(7);

        A[4][2].setrow(4);
        A[4][2].setcol(2);
        A[4][3].setrow(4);
        A[4][3].setcol(3);
        A[4][6].setrow(4);
        A[4][6].setcol(6);
        A[4][7].setrow(4);
        A[4][7].setcol(7);
        game = new Controller();
        init_P();
    }

    /**
     * Pre: set at the current row and column the piece p
     *
     * @param row
     * @param column
     * @param p
     *
     * Post: the piece p has been set
     */
    public void set_tablo(int row, int column, Piece p) {

        A[row][column] = p;

    }

    /**
     * Pre Return the piece which is in the the exact row and column
     *
     * @param row
     * @param col
     * @return
     *
     * Post : the right piece has been returned
     */
    public Piece get_Piece(int row, int col) {
        if(A[row][col]!=null)
        {
        return A[row][col];
        }
        return (null);
    }

    /**
     * Pre: take each peach from the arraylist and put it at the right spot of
     * the board
     *
     * Post: take each peach from the arraylist and put it at the right spot of
     * the board
     */
    public void init_P() {
        int o = 0, L = 0;
        int k = 0, n = 0;
        int si2 = game.getPieces_P2().size();
        int si1 = game.getPieces_P1().size();
        for (int j = 0; j < 8; j++) {

            for (int i = 0; i < 10; i++) {
                if (j <= 2) {
                    //System.out.println(si2);
                    if (k < si2) {
                        int rank2 = game.getPieces_P2().get(k).getrank();
                        if (rank2 == 10) {
                            A[j][i] = game.getPieces_P2().get(k);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            k++;
                        } else if (rank2 == 10) {
                            A[j][i] = game.getPieces_P2().get(k);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            k++;
                        } else if (rank2 == 9) {
                            A[j][i] = game.getPieces_P2().get(k);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            k++;
                        } else if (rank2 == 8) {
                            A[j][i] = game.getPieces_P2().get(k);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            k++;
                        } else if (rank2 == 7) {
                            A[j][i] = game.getPieces_P2().get(k);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            k++;
                        } else if (rank2 == 6) {
                            A[j][i] = game.getPieces_P2().get(k);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            k++;
                        } else if (rank2 == 5) {
                            A[j][i] = game.getPieces_P2().get(k);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            k++;
                        } else if (rank2 == 4) {
                            A[j][i] = game.getPieces_P2().get(k);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            k++;
                        } else if (rank2 == 3) {
                            A[j][i] = game.getPieces_P2().get(k);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            k++;
                        } else if (rank2 == 2) {
                            A[j][i] = game.getPieces_P2().get(k);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            k++;
                        } else if (rank2 == 1) {
                            A[j][i] = game.getPieces_P2().get(k);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            k++;
                        } else if (rank2 == 0) {
                            if (L == 0) {
                                A[j][i] = game.getPieces_P2().get(k);
                                A[j][i].setrow(j);
                                A[j][i].setcol(i);
                                L = 1;
                                k++;
                            } else {
                                A[j][i] = game.getPieces_P2().get(k);
                                A[j][i].setrow(j);
                                A[j][i].setcol(i);
                                k++;
                            }
                        }
                    }
                } else if (j >= 5) {
                    //System.out.println(si2);
                    if (n < si1) {
                        int rank = game.getPieces_P1().get(n).getrank();
                        if (rank == 10) {
                            A[j][i] = game.getPieces_P1().get(n);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            n++;
                        } else if (rank == 10) {
                            A[j][i] = game.getPieces_P1().get(n);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            n++;
                        } else if (rank == 9) {
                            A[j][i] = game.getPieces_P1().get(n);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            n++;
                        } else if (rank == 8) {
                            A[j][i] = game.getPieces_P1().get(n);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            n++;
                        } else if (rank == 7) {
                            A[j][i] = game.getPieces_P1().get(n);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            n++;
                        } else if (rank == 6) {
                            A[j][i] = game.getPieces_P1().get(n);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            n++;
                        } else if (rank == 5) {
                            A[j][i] = game.getPieces_P1().get(n);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            n++;
                        } else if (rank == 4) {
                            A[j][i] = game.getPieces_P1().get(n);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            n++;
                        } else if (rank == 3) {
                            A[j][i] = game.getPieces_P1().get(n);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            n++;
                        } else if (rank == 2) {
                            A[j][i] = game.getPieces_P1().get(n);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            n++;
                        } else if (rank == 1) {
                            A[j][i] = game.getPieces_P1().get(n);
                            A[j][i].setrow(j);
                            A[j][i].setcol(i);
                            n++;
                        } else if (rank == 0) {
                            if (L == 0) {
                                A[j][i] = game.getPieces_P1().get(n);
                                A[j][i].setrow(j);
                                A[j][i].setcol(i);
                                L = 1;
                                n++;
                            } else {
                                A[j][i] = game.getPieces_P1().get(n);
                                A[j][i].setrow(j);
                                A[j][i].setcol(i);
                                n++;
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Pre return who player have to play Post return who player have to play
     *
     * @return Post return who player have to play
     */
    public boolean getP1_play() {
        return game.P1_play;
    }

    /**
     * Pre return who player have to play
     *
     * @return Post return who player have to play
     */
    public boolean getP2_play() {
        return game.P2_play;
    }
}

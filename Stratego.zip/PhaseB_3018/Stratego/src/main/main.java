/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import View.GraphicUI;
import java.io.IOException;

/**
 *
 * @author andre_000
 */
public class main {
    /**
     * Pre Constructor which strarts the game
     * 
     * @param args
     * @throws IOException 
     * Post the game starts 
     */
    public static void main(String[] args) throws IOException{
        GraphicUI j = new GraphicUI();
    }
}

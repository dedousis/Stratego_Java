/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Piece;
import Model.Player;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author andre_000
 */
public class ControllerTest {
    
    public ControllerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Ress_P1 method, of class Controller.
     */
    @Test
    public void testRess_P1() {
        System.out.println("Ress_P1");
        Controller instance = new Controller();
        Piece expResult = null;
        Piece result = instance.Ress_P1();
        assertEquals(expResult, result);

    }

    /**
     * Test of Ress_P2 method, of class Controller.
     */
    @Test
    public void testRess_P2() {
        System.out.println("Ress_P2");
        Controller instance = new Controller();
        Piece expResult = null;
        Piece result = instance.Ress_P2();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of num_res_P1 method, of class Controller.
     */
    @Test
    public void testNum_res_P1() {
        System.out.println("num_res_P1");
        Controller instance = new Controller();
        int expResult = 0;
        int result = instance.num_res_P1();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
 
    }

    /**
     * Test of num_res_P2 method, of class Controller.
     */
    @Test
    public void testNum_res_P2() {
        System.out.println("num_res_P2");
        Controller instance = new Controller();
        int expResult = 0;
        int result = instance.num_res_P2();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
   
    }

    /**
     * Test of P1_play method, of class Controller.
     */
    @Test
    public void testP1_play() {
        System.out.println("P1_play");
        Controller instance = new Controller();
        boolean expResult = true;
        boolean result = instance.P1_play();
        assertEquals(expResult, result);

    }

    /**
     * Test of P2_play method, of class Controller.
     */
    @Test
    public void testP2_play() {
        System.out.println("P2_play");
        Controller instance = new Controller();
        boolean expResult = false;
        boolean result = instance.P2_play();
        assertEquals(expResult, result);

    }

    /**
     * Test of getPieces_P1 method, of class Controller.
     */
    @Test
    public void testGetPieces_P1() {
        System.out.println("getPieces_P1");
        Controller instance = new Controller();
        ArrayList<Piece> expResult = null;
        ArrayList<Piece> result = instance.getPieces_P1();
        assertEquals(expResult, result);
 
    }

    /**
     * Test of getPieces_P2 method, of class Controller.
     */
    @Test
    public void testGetPieces_P2() {
        System.out.println("getPieces_P2");
        Controller instance = new Controller();
        ArrayList<Piece> expResult = null;
        ArrayList<Piece> result = instance.getPieces_P2();
        assertEquals(expResult, result);

    }

    /**
     * Test of getP1 method, of class Controller.
     */
    @Test
    public void testGetP1() {
        System.out.println("getP1");
        int rank = 0;
        Controller instance = new Controller();
        Piece expResult = null;
        Piece result = instance.getP1(rank);
        assertEquals(expResult, result);

    }

    /**
     * Test of getP2 method, of class Controller.
     */
    @Test
    public void testGetP2() {
        System.out.println("getP2");
        int rank = 0;
        Controller instance = new Controller();
        Piece expResult = null;
        Piece result = instance.getP2(rank);
        assertEquals(expResult, result);

    }

    /**
     * Test of add_dead_p1 method, of class Controller.
     */
    @Test
    public void testAdd_dead_p1() {
        System.out.println("add_dead_p1");
        int rank = 0;
        Controller instance = new Controller();
        instance.add_dead_p1(rank);
 
    }

    /**
     * Test of add_dead_p2 method, of class Controller.
     */
    @Test
    public void testAdd_dead_p2() {
        System.out.println("add_dead_p2");
        int rank = 0;
        Controller instance = new Controller();
        instance.add_dead_p2(rank);
  
    }

    /**
     * Test of getSideP1 method, of class Controller.
     */
    @Test
    public void testGetSideP1() {
        System.out.println("getSideP1");
        Controller instance = new Controller();
        Player.team expResult = null;
        Player.team result = instance.getSideP1();
        assertEquals(expResult, result);

    }

    /**
     * Test of getSideP2 method, of class Controller.
     */
    @Test
    public void testGetSideP2() {
        System.out.println("getSideP2");
        Controller instance = new Controller();
        Player.team expResult = null;
        Player.team result = instance.getSideP2();
        assertEquals(expResult, result);

    }

    /**
     * Test of setCordinates method, of class Controller.
     */
    @Test
    public void testSetCordinates() {
        System.out.println("setCordinates");
        int row = 0;
        int columns = 0;
        Piece p = null;
        Controller instance = new Controller();
        instance.setCordinates(row, columns, p);

    }

    /**
     * Test of getCordinates method, of class Controller.
     */
    @Test
    public void testGetCordinates() {
        System.out.println("getCordinates");
        int row = 0;
        int columns = 0;
        Controller instance = new Controller();
        Piece expResult = null;
        Piece result = instance.getCordinates(row, columns);
        assertEquals(expResult, result);
  
    }

    /**
     * Test of get_piecesLeftP1 method, of class Controller.
     */
    @Test
    public void testGet_piecesLeftP1() {
        System.out.println("get_piecesLeftP1");
        Controller instance = new Controller();
        int expResult = 30;
        int result = instance.get_piecesLeftP1();
        assertEquals(expResult, result);

    }

    /**
     * Test of get_piecesLeftP2 method, of class Controller.
     */
    @Test
    public void testGet_piecesLeftP2() {
        System.out.println("get_piecesLeftP2");
        Controller instance = new Controller();
        int expResult = 30;
        int result = instance.get_piecesLeftP2();
        assertEquals(expResult, result);
 
    }

    /**
     * Test of getName_P1 method, of class Controller.
     */
    @Test
    public void testGetName_P1() {
        System.out.println("getName_P1");
        Controller instance = new Controller();
        String expResult = "";
        String result = instance.getName_P1();
        assertEquals(expResult, result);
 
    }

    /**
     * Test of getName_P2 method, of class Controller.
     */
    @Test
    public void testGetName_P2() {
        System.out.println("getName_P2");
        Controller instance = new Controller();
        String expResult = "";
        String result = instance.getName_P2();
        assertEquals(expResult, result);

    }

    /**
     * Test of getDead_P1 method, of class Controller.
     */
    @Test
    public void testGetDead_P1() {
        System.out.println("getDead_P1");
        Controller instance = new Controller();
        int expResult = 0;
        int result = instance.getDead_P1();
        assertEquals(expResult, result);

    }

    /**
     * Test of getDead_P2 method, of class Controller.
     */
    @Test
    public void testGetDead_P2() {
        System.out.println("getDead_P2");
        Controller instance = new Controller();
        int expResult = 0;
        int result = instance.getDead_P2();
        assertEquals(expResult, result);

    }

    /**
     * Test of SetLast method, of class Controller.
     */
    @Test
    public void testSetLast() {
        System.out.println("SetLast");
        Player p = null;
        Controller instance = new Controller();
        instance.SetLast(p);

    }

    /**
     * Test of getLast method, of class Controller.
     */
    @Test
    public void testGetLast() {
        System.out.println("getLast");
        Controller instance = new Controller();
        Player expResult = null;
        Player result = instance.getLast();
        assertEquals(expResult, result);

    }
    
}

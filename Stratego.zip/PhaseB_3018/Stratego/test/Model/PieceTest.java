/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author andre_000
 */
public class PieceTest {
    
    public PieceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getColor method, of class Piece.
     */
    @Test
    public void testGetColor() {
        System.out.println("getColor");
        Piece instance = new PieceImpl();
        Piece.color expResult = null;
        Piece.color result = instance.getColor();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of setrow method, of class Piece.
     */
    @Test
    public void testSetrow() {
        System.out.println("setrow");
        int row = 0;
        Piece instance = new PieceImpl();
        instance.setrow(row);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getrow method, of class Piece.
     */
    @Test
    public void testGetrow() {
        System.out.println("getrow");
        Piece instance = new PieceImpl();
        int expResult = 0;
        int result = instance.getrow();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of setcol method, of class Piece.
     */
    @Test
    public void testSetcol() {
        System.out.println("setcol");
        int column = 0;
        Piece instance = new PieceImpl();
        instance.setcol(column);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getcol method, of class Piece.
     */
    @Test
    public void testGetcol() {
        System.out.println("getcol");
        Piece instance = new PieceImpl();
        int expResult = 0;
        int result = instance.getcol();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getrank method, of class Piece.
     */
    @Test
    public void testGetrank() {
        System.out.println("getrank");
        Piece instance = new PieceImpl();
        int expResult = 0;
        int result = instance.getrank();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
 
    }

    public class PieceImpl extends Piece {
    }
    
}
